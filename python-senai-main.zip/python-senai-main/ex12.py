idade= int(input("Digite sua data de nascimento: "))
ano= 2024-idade
if(ano >=16):
    print("Voce pode votar")

else:
    print("Voce nao pode votar")