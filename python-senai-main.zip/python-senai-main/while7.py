i = 100
while i>0:
    i-= 5
    print(i)
