x = 0 
while x<=10: 
    print(f" 7 x {x} = ",x*7)
    x=1