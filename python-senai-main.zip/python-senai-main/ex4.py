#Imprima os números de 1 a 100, pulando de 5 em 5.
for i in range(0, 100, 5):
    print(i)