lista = ["macaco", "franca", 300,100,7]
print((lista[2]))