def soma(num1,num2):
    return num1+ num2 
num1= int(input("Digite um numero: "))
num2= int(input("Digite mais um numero:"))

print("{}".format(num1+num2))