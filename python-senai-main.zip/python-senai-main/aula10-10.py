lista = [1,2,3,4,5,6,7,8,9]
lista.pop(0)
print(lista)