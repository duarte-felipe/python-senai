n = int(input("Digite um numero: "))
cont = 1 
while 2 ** cont<n: 
    cont+= 1
    print(2**cont)