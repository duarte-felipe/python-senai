# entrada do número
num = float(input("Digite um número: "))

# imprime a relação com zero
if num < 0:
    print("Menor que zero")
elif num == 0:
    print("Igual a zero")
else:
    print("Maior que zero")
