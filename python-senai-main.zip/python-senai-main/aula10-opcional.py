primeiro = [1,2,3,4]

print(len(primeiro))

print(primeiro[0])

print(primeiro[2:4]) 

#concatenaçao funciona com (+) pra somar na lista e (==) para comparar listas 
#concatenaçao 
lista = [1,2,3,4]
#print concatenaçao
print(lista+[5,6])

#       END           
# end nao quebra a linha, imprime tudo na frente do outro "1,2,3,4, com end"
# for n in [1,2,3,4]:
#   print(n,end= " ")

#operador IN 
lista = [1,2,3]
#3 tem na lista ou seja TRUE 
print(3 in lista)
#0 nao tem na lista e ele imprime FALSE
print(0 in lista)
#metodo append adc 1 coisa so pra lista 