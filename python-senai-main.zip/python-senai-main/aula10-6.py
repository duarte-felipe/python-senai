lista = ["brasil", "franca", 300]
print((lista[2]))