def mult(n1,n2):
    return n1*n2

n1 = float(input("Digite um numero: "))
n2 = float(input("Digite outro numero: "))

print(n1*n2)