
n = int(input("Digite um numero: "))
cont= 1 
while cont ** 2< n:
    print(cont**2)
    cont+= 1 