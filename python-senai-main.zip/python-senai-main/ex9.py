num1= int(input("Digite um numero: "))
num2 = int(input("Digite outro numero: "))

if(num1!=num2):
    print("O primeiro numero e diferente do outro!")

else:
    print("O primeiro numero nao e diferente ao outro!")