#Imprima os números de 100 a 1, pulando de 10 em 10.
for i in range(100, 1, -10):
    print(i)