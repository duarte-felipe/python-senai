msg = input("Escreva uma frase: ")

for i in range(5):
    i+1== 5 
    print(msg)