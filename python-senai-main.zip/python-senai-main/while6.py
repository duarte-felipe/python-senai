senha = 1
while(senha !=123):
    print("Senha invalida")

    senha = int(input("Digite a senha: "))
