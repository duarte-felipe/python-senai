n = int(input("Digite um numero: "))
cont= 1
while cont<= n:
    cont+= 1 
    if(cont%10== 0):
        print(cont)