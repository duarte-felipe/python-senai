num1 = 80  
for i in range(80):
    num1-=1 #num1 = num1-1
    print(num1)
