inf = input("Eu gosto de estudar algoritimos")

for i in range(20):
    i+1== 20
    print(inf)