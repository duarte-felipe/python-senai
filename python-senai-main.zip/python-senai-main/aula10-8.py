lista = [1,2,3,4]

print(lista)

lista.append(5)

print(lista)