num= float (input("Digite um numero: "))

if(num>=13 and num<= 17):
    print("E um adolescente")

else:
    print("Nao e um adolescente")