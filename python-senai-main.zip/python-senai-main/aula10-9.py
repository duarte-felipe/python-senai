lista = [1,2,3,4]

lista.insert(0,5)

print(lista)