def div(num1, num2):
    return num1 / num2 

num1= float(input("DIgite um numero: "))
num2= float(input("Digite outro numero: "))

print("Esses numeros divididos sao {}".format(num1/num2))