#def basico (diferente do pedido, o usuario ira conceder as informaçoes)
def calculo(largura, altura):
    return largura * altura

num1= float(input("DIgite a largura: "))
num2= float(input("DIgite a altura: "))

print("A area desses valores e de {}".format(num1*num2))