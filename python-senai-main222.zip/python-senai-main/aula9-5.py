def nome1():
    return f"ola, {nome}!"

nome= str(input("Digite seu nome: "))

print (nome"{}".format(nome))