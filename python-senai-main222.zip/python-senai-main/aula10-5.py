lista = ["macaco", "franca", 300]
print((lista[0]))