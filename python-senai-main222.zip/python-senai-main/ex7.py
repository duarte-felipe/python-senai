#Leia o nome do usuário e escreva o nome dele na tela 10 vezes.
msg = input("Escreva seu nome: ")

for i in range(10):
    i+1== 10 
    print(msg)