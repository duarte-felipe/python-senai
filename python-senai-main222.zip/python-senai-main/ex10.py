idade = int(input("Digite a i idade"))
#if se for maior de 18
if(idade>=18):
    print("Pode entrar na festa!")
#se for menor de 18
else:
    print("Nao pode entrar na festa!")

