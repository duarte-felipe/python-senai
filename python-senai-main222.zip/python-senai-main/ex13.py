senha = int(input("Escreva sua senha: "))

if(senha ==1234):
    print("Acesso permitido")

else:
    print("Acesso negado")

