lista = ["abacaxi","pessego","beterraba"]
print( lista )

