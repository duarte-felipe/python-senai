lista = ([])

print(lista)