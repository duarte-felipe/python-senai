def sub(n1,n2):
    return n1 - n2
#n1 = int(input("Digite um numero: "))
#n2 = int(input("Digite outro numero: "))

print(sub(50,10))

#print("{}".format(n1-n2))3
