lista = ["beterraba", 10,30]
print(lista)